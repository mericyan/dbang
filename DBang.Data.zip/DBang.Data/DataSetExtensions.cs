﻿using System.Data;

namespace DBang.Data
{
    public static class DataSetExtensions
    {
        public static string GetShrinkedXml(this DataSet dataSet)
        {
            if (dataSet == null || dataSet.Tables.Count == 0 || dataSet.Tables[0].Rows.Count == 0)
                return null;

            string xmlResult = "<NewDataSet>";

            for (int i = 0; i < dataSet.Tables.Count; i++)
            {
                DataTable table = dataSet.Tables[i];

                foreach (DataColumn column in table.Columns)
                    column.ColumnName = column.ColumnName.Replace("].&[", "_").Replace("].[", "_").Replace("[", "").Replace("]", "").Replace(".", "_");

                for (int j = 0; j < table.Rows.Count; j++)
                {
                    DataRow row = table.Rows[j];
                    xmlResult += "<Table" + i + ">";

                    for (int k = 0; k < table.Columns.Count; k++)
                    {
                        DataColumn column = table.Columns[k];
                        xmlResult += "<" + column.ColumnName + ">" + row[k] + "</" + column.ColumnName + ">";
                    }

                    xmlResult += "</Table" + i + ">";
                }
            }

            return xmlResult + "</NewDataSet>";
        }
    }
}