using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace DBang.Data
{
    public class Database : IDatabase
    {
        private readonly Dictionary<string, string> _connStrings;
        private readonly DbProviderFactory _dbProviderFactory;
        private readonly string _defaultDataSource;

        public Database(string providerInvariantName, params string[] connStrings)
        {
            _connStrings = new Dictionary<string, string>();
            _dbProviderFactory = DbProviderFactories.GetFactory(providerInvariantName);

            foreach (string connString in connStrings)
            {
                using (DbConnection conn = _dbProviderFactory.CreateConnection())
                {
                    conn.ConnectionString = connString;
                    _connStrings[conn.DataSource] = connString;

                    if (_defaultDataSource == null)
                        _defaultDataSource = conn.DataSource;
                }
            }
        }

        #region IDatabase Members

        public object ExecuteScalar(string cmdText, params IDataParameter[] parameters)
        {
            return ExecuteScalar(_defaultDataSource, cmdText, parameters);
        }

        public int ExecuteNonQuery(string cmdText, params IDataParameter[] parameters)
        {
            return ExecuteNonQuery(_defaultDataSource, cmdText, parameters);
        }

        public string ExecuteXml(string cmdText, params IDataParameter[] parameters)
        {
            return ExecuteXml(_defaultDataSource, cmdText, parameters);
        }

        public DataSet ExecuteDataSet(string cmdText, params IDataParameter[] parameters)
        {
            return ExecuteDataSet(_defaultDataSource, cmdText, parameters);
        }

        public object ExecuteScalar(string dataSource, string cmdText, params IDataParameter[] parameters)
        {
            Func<DbCommand, object> executeScalar = comm => comm.ExecuteScalar();

            return Execute(executeScalar, dataSource, cmdText, parameters);
        }

        public int ExecuteNonQuery(string dataSource, string cmdText, params IDataParameter[] parameters)
        {
            Func<DbCommand, int> executeNonQuery = comm => comm.ExecuteNonQuery();

            return Execute(executeNonQuery, dataSource, cmdText, parameters);
        }

        public string ExecuteXml(string dataSource, string cmdText, params IDataParameter[] parameters)
        {
            DataSet dsResult = ExecuteDataSet(dataSource, cmdText, parameters);

            return dsResult.GetShrinkedXml();
        }

        public DataSet ExecuteDataSet(string dataSource, string cmdText, params IDataParameter[] parameters)
        {
            Func<DbCommand, DataSet> executeDataSet = comm =>
                                                      {
                                                          var dsResult = new DataSet();

                                                          using (DbDataAdapter adapter = _dbProviderFactory.CreateDataAdapter())
                                                          {
                                                              adapter.SelectCommand = comm;
                                                              adapter.Fill(dsResult);
                                                          }

                                                          return dsResult;
                                                      };

            return Execute(executeDataSet, dataSource, cmdText, parameters);
        }

        #endregion

        private TResult Execute<TResult>(Func<DbCommand, TResult> execute, string dataSource, string cmdText, params IDataParameter[] parameters)
        {
            TResult result = default(TResult);

            using (DbConnection conn = _dbProviderFactory.CreateConnection())
            {
                using (DbCommand comm = conn.CreateCommand())
                {
                    try
                    {
                        if (parameters != null && parameters.Length > 0)
                            comm.AddParameters(parameters);

                        comm.CommandText = cmdText;
                        comm.Connection.ConnectionString = _connStrings[dataSource];
                        comm.Connection.Open();

                        using (comm.Transaction = conn.BeginTransaction())
                        {
                            result = execute(comm);
                            comm.Transaction.Commit();
                        }
                    }
                    catch (Exception e)
                    {
                        e.Alert(this);

                        if (comm.Transaction != null)
                            comm.Transaction.Rollback();
                    }
                }
            }

            return result;
        }
    }
}